﻿namespace HeroAPI.ViewModels
{
    public class HeroCreate
    {
        public string HeroName { get; set; }
    }
}