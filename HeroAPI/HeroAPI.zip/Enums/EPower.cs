﻿namespace HeroAPI.Enums
{
    public enum EPower
    {
        Fly = 1,
        Strength,
        LaserEyes,
        Rich,
        Speed,
        Magic,
        Thunder
    }
}